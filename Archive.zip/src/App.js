import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.scss";
import Layout from "./components/layout";
import HomePage from "./pages/home/home";

function App() {
	return (
		<BrowserRouter>
			<Routes>
				<Route exact path="*" element={<Layout />}>
					<Route index element={<HomePage />} />
					{/* <Route exact path="login" element={<LoginRegister />} /> */}
				</Route>
			</Routes>
		</BrowserRouter>
	);
}

export default App;
