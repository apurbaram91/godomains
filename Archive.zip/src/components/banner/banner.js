import React from "react";
import "./banner.scss";
import BannerImage from "../../assets/images/banner.png";
import Language from "../../assets/images/language.svg";

function banner(props) {
	return (
		<div className="banner">
			<img src={BannerImage} alt="" />
			<div className="content">
				<h1>
					Decentralized Domains <br />
					for Web3 Ecosystem
				</h1>
				<p>Give your crypto wallet address a human readable address!</p>
				<div className="search-area">
					<button className="language" type="button">
						<img src={Language} alt="" />
					</button>
					<input type="text" placeholder="Start typing the domain you want" />
					<button className="find" type="button">
						Find
					</button>
				</div>
				<ul className="option-area">
					<li>
						<span className="icon"></span>
						<p>Install XDC Pay</p>
					</li>
					<li>
						<span className="icon"></span>
						<p>Top Up XDC</p>
					</li>
					<li>
						<span className="icon"></span>
						<p>Search Domain</p>
					</li>
					<li>
						<span className="icon"></span>
						<p>Register</p>
					</li>
				</ul>
			</div>
		</div>
	);
}

export default banner;
