import React from "react";
import "./buy-domain.scss";
import Ethereum from "../../assets/images/ethe.png";
import Polygon from "../../assets/images/poly.png";
import Solana from "../../assets/images/sola.png";
import Binance from "../../assets/images/bina.png";
import { Link } from "react-router-dom";

const reviewData = [
	{
		image: Ethereum,
		title: "Build using ",
		subTitle: "Ethereum",
		description:
			"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore",
	},
	{
		image: Polygon,
		title: "Build using",
		subTitle: "Polygon",
		description:
			"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore",
	},
	{
		image: Solana,
		title: "Build using",
		subTitle: "Solana",
		description:
			"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore",
	},
	{
		image: Binance,
		title: "Build using",
		subTitle: "Binance",
		description:
			"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore",
	},
];

function BuyDomain() {
	return (
		<div className="buy-domain">
			<div className="container">
				<h3>
					<span>stastics</span>
					Buy Now. Store Domain. <br />
					Sell Later for a Profit.
				</h3>
				<div className="item-row">
					{reviewData.map((data, i) => (
						<>
							<div className="item" key={i}>
								<img src={data.image} alt="" />
								<div className="details">
									<h4>{data.title}</h4>
									<h5>{data.subTitle}</h5>
									<p>{data.description}</p>
									<Link to={""}>Learn more</Link>
								</div>
							</div>
						</>
					))}
				</div>
			</div>
		</div>
	);
}

export default BuyDomain;
