import React from "react";
import "./footer.scss";
import Logo from "../../assets/images/logo.svg";
import Linkedin from "../../assets/images/Linkedin.svg";
import Twitter from "../../assets/images/Twitter.svg";
import Facebook from "../../assets/images/Facebook.svg";
import Instagram from "../../assets/images/Instagram.svg";

export default function Footer() {
	return (
		<div className="footer">
			<div className="container">
				<div className="f-logo">
					<img src={Logo} alt="" />
				</div>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
					eiusmod tempor incididunt ut labore et dolore magna aliqua.
				</p>
				<ul className="social">
					<li>
						<a href="">
							<img src={Linkedin} alt="" />
						</a>
					</li>
					<li>
						<a href="">
							<img src={Twitter} alt="" />
						</a>
					</li>
					<li>
						<a href="">
							<img src={Facebook} alt="" />
						</a>
					</li>
					<li>
						<a href="">
							<img src={Instagram} alt="" />
						</a>
					</li>
				</ul>
				<p>
					Copyright © 2022 <a href="#">Godomains.com</a> | All rights reserved.
				</p>
			</div>
		</div>
	);
}
