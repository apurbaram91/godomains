import React from "react";
import "./header.scss";
import Logo from "../../assets/images/logo.svg";

function Header() {
	return (
		<header>
			<div className="container">
				<div className="logo">
					<img src={Logo} alt="" />
				</div>
				<div className="nav-block">
					<ul className="h-nav">
						<li>
							<a href="">Home</a>
						</li>
						<li>
							<a href="">Why Us</a>
						</li>
						<li>
							<a href="">Features</a>
						</li>
						<li>
							<a href="">Pricing</a>
						</li>
						<li>
							<a href="">Contacts</a>
						</li>
					</ul>
				</div>
				<div className="action-block"></div>
			</div>
		</header>
	);
}

export default Header;
