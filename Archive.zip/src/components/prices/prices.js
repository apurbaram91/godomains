import React from "react";
import "./prices.scss";
import Ethereum from "../../assets/images/ethe.png";
import Polygon from "../../assets/images/poly.png";
import Solana from "../../assets/images/sola.png";
import Binance from "../../assets/images/bina.png";
import { Link } from "react-router-dom";

const reviewData = [
	{
		title: "Free",
		price: "$0",
		description: "Per Month",
		items: [
			{
				value: "Unlimited API Calls",
			},
			{
				value: "5 RQ/S",
			},
			{
				value: "All main & Testnet",
			},
		],
	},
	{
		title: "Start",
		price: "$9",
		description: "Per Month",
		items: [
			{
				value: "Unlimited API Calls",
			},
			{
				value: "5 RQ/S",
			},
			{
				value: "All main & Testnet",
			},
		],
	},
	{
		title: "Basic",
		price: "$48",
		description: "Per Month",
		items: [
			{
				value: "Unlimited API Calls",
			},
			{
				value: "5 RQ/S",
			},
			{
				value: "All main & Testnet",
			},
		],
	},
	{
		title: "Enterprise",
		price: "Binance",
		description: "Per Month",
		items: [
			{
				value: "Unlimited API Calls",
			},
			{
				value: "5 RQ/S",
			},
			{
				value: "All main & Testnet",
			},
		],
	},
];

function Prices() {
	return (
		<div className="prices">
			<div className="container">
				<h3>
					<span>pricing</span>
					Price so low that it's <br />
					practically free
				</h3>
				<div className="item-row">
					{reviewData.map((data, i) => (
						<div className="item" key={i}>
							<h4>{data.title}</h4>
							<h5>
								<strong>
									{data.title !== "Enterprise" ? data.price : "Contact Us"}
								</strong>
								{data.title !== "Enterprise" ? " / month" : ""}
							</h5>
							<p>{data.description}</p>
							<ul>
								{data.items.map((val) => (
									<li>
										<svg
											width="24"
											height="20"
											viewBox="0 0 24 20"
											fill="none"
											xmlns="http://www.w3.org/2000/svg"
										>
											<path
												d="M12 14.7281V18.5194C12.0005 18.8122 12.0887 19.0983 12.2535 19.3416C12.4184 19.585 12.6524 19.7747 12.9262 19.8868C13.2001 19.999 13.5014 20.0286 13.7922 19.9719C14.083 19.9153 14.3504 19.7748 14.5605 19.5683L24 10.3708L14.5605 1.17487C14.4215 1.03681 14.2563 0.92725 14.0743 0.852488C13.8923 0.777727 13.6971 0.739241 13.5 0.739241C13.3029 0.739241 13.1077 0.777727 12.9257 0.852488C12.7437 0.92725 12.5785 1.03681 12.4395 1.17487C12.3001 1.31236 12.1896 1.47565 12.1142 1.65538C12.0388 1.83511 12 2.02777 12 2.22232V5.9099C7.875 5.80916 3.3675 5.07134 0 0V1.48155C0 8.34557 5.25 13.9903 12 14.7281Z"
												fill="#1E1810"
											/>
										</svg>
										<p>{val.value}</p>
									</li>
								))}
							</ul>
							<Link to={""}>
								get started
								<svg
									width="20"
									height="14"
									viewBox="0 0 20 14"
									fill="none"
									xmlns="http://www.w3.org/2000/svg"
								>
									<path
										d="M13.3449 0.619007C13.0938 0.336954 12.669 0.299347 12.3793 0.524989C12.0896 0.750631 12.051 1.18311 12.2828 1.46517C12.3214 1.50277 12.3407 1.52158 12.3793 1.55918L17.3036 6.35408H1.02449C0.638269 6.37289 0.348605 6.69255 0.367916 7.04981C0.387227 7.38828 0.65758 7.67033 1.02449 7.68913H17.3036L12.36 12.484C12.109 12.7473 12.109 13.161 12.36 13.4242C12.6304 13.6875 13.0552 13.6875 13.3255 13.4242L19.4278 7.4823C19.6981 7.23785 19.6982 6.82417 19.4471 6.56092L19.4278 6.54212L13.3449 0.619007Z"
										fill="#1E1810"
									/>
									<path
										fill-rule="evenodd"
										clip-rule="evenodd"
										d="M12.2828 1.46514C12.051 1.18309 12.0897 0.750607 12.3793 0.524964C12.669 0.299322 13.0938 0.336929 13.3449 0.618982L19.4471 6.5609C19.6982 6.82415 19.6982 7.23782 19.4278 7.48227L13.3256 13.4242C13.0552 13.6874 12.6304 13.6874 12.36 13.4242C12.109 13.1609 12.109 12.7473 12.36 12.484L17.3036 7.68911H1.02451C0.657599 7.67031 0.387246 7.38825 0.367935 7.04979C0.348624 6.69252 0.638288 6.37286 1.02451 6.35406H17.3036L12.2828 1.46514ZM16.3805 5.97568L12.0654 1.77388L12.016 1.72578L12.0028 1.70971C11.6391 1.26711 11.6951 0.583767 12.1581 0.223061C12.5954 -0.117542 13.2258 -0.063089 13.6054 0.352224L19.704 6.29061L19.7088 6.29561C20.0949 6.70051 20.1103 7.36269 19.6754 7.76164L13.5775 13.6993C13.1657 14.1002 12.5198 14.1002 12.1081 13.6993L12.1031 13.6945L12.0984 13.6895C11.7069 13.279 11.7069 12.6292 12.0984 12.2187L12.1034 12.2135L16.3779 8.06749H1.01539L1.00629 8.06702C0.461408 8.0391 0.0324339 7.6125 0.00159649 7.07201L0.00152997 7.07084C-0.0303225 6.48152 0.439497 6.00374 1.0072 5.9761L1.01585 5.97568H16.3805Z"
										fill="#1E1810"
									/>
								</svg>
							</Link>
						</div>
					))}
				</div>
			</div>
		</div>
	);
}

export default Prices;
