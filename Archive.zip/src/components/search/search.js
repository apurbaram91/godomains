import React from "react";
import "./search.scss";
import Language from "../../assets/images/envelop.svg";

function Search() {
	return (
		<div className="search">
			<div className="container">
				<h3>
					Your search for the right <br /> domain ends here!
				</h3>
				<p>
					Choose from the wide range of decentralized choices and never make a
					compromise for your business.
				</p>
				<div className="search-area">
					<button className="language" type="button">
						<img src={Language} alt="" />
					</button>
					<input type="text" placeholder="Start typing the domain you want" />
					<button className="find" type="button">
						Search
					</button>
				</div>
			</div>
		</div>
	);
}

export default Search;
