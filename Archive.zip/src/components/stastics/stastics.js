import React from "react";
import "./stastics.scss";

const ProblemsData = [
	{
		title: "166",
		description: "Total Domains Sold",
	},
	{
		title: "177",
		description: "Cost to Host a Domain",
	},
	{
		title: "199",
		description: "Renewal Fees",
	},
	{
		title: "24/7",
		description: "Customer Support",
	},
];

function Stastics() {
	return (
		<div className="stastics">
			<div className="container">
				<h3>
					<span>stastics</span>
					GoDomains by the Numbers
				</h3>
				<div className="item-row">
					{ProblemsData.map((data, i) => (
						<div className="stastics-item" key={i}>
							<h4>{data.title}</h4>
							<p>{data.description}</p>
						</div>
					))}
				</div>
			</div>
		</div>
	);
}

export default Stastics;
