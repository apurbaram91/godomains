import React from "react";
import "./type.scss";
import Language from "../../assets/images/envelop.svg";

function Type() {
	return (
		<div className="type">
			<div className="container">
				<div className="box">
					<h4>one step away</h4>
					<h3>Just Type your Domain Name</h3>

					<div className="search-area">
						<button className="language" type="button">
							<img src={Language} alt="" />
						</button>
						<input type="text" placeholder="Start typing the domain you want" />
						<button className="find" type="button">
							Search
						</button>
					</div>
				</div>
			</div>
		</div>
	);
}

export default Type;
