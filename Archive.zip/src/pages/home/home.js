import React from "react";
import BannerImage from "../../components/banner/banner";
import BuyDomain from "../../components/buy-domain/buy-domain";
import Faq from "../../components/faq/faq";
import IncludesUser from "../../components/includes-users/includes-users";
import Includes from "../../components/includes/includes";
import Prices from "../../components/prices/prices";
import Problems from "../../components/problems/problems";
import Search from "../../components/search/search";
import StasticsSteps from "../../components/stastics-steps/stastics-steps";
import Stastics from "../../components/stastics/stastics";
import Type from "../../components/type/type";

function HomePage() {
	return (
		<>
			<BannerImage />
			<Problems />
			<Stastics />
			<Search />
			<StasticsSteps />
			<Includes />
			<IncludesUser />
			<BuyDomain />
			<Prices />
			<Faq />
			<Type />
		</>
	);
}

export default HomePage;
